<?php	
$db_host = 'localhost';
$db_user = 'root';
$db_pwd =  '123456';
$db_name = 'test';
//数据表前缀
$db_tablepre = '';
//数据表编码
$db_charset = 'utf8';
?>