<?php
require_once(dirname(__FILE__).'/include/config.inc.php'); 
//初始化参数
$action = isset($action) ? $action : '';
//获取级联
if($action == 'uploadFile'){
	//判断是否上传文件
	if(!empty($_FILES['headimg']['name'])){
		$file_size = $_FILES['headimg']['size'];  
		if($file_size > 2*1024*1024) {  
			ShowMsg("文件过大，不能上传大于2M的文件","-1");
			exit();  
		}  
		$file_type = $_FILES['headimg']['type'];  
		
		if($file_type!="image/jpeg" && $file_type!='image/pjpeg' && $file_type!='image/png') {  
			ShowMsg("文件类型只能为jpg格式或png格式","-1");
			exit();  
		}  
		//判断是否上传成功（是否使用post方式上传）  
		if(is_uploaded_file($_FILES['headimg']['tmp_name'])) {  
			//把文件转存到你希望的目录（不要使用copy函数）  
			$uploaded_file=$_FILES['headimg']['tmp_name'];  
	  
			//我们给每个用户动态的创建一个文件夹  
			$user_path = $_SERVER['DOCUMENT_ROOT']."/uploads/image/avatar";  
			//判断该用户文件夹是否已经有这个文件夹  
			if(!file_exists($user_path)) {  
				mkdir($user_path);  
			}  
			 
			$file_true_name = $_FILES['headimg']['name'];  //文件真实名字
			$file_name = time().rand(1000,9999).substr($file_true_name,strrpos($file_true_name,".")); //文件保存名字
			$move_to_file = $user_path."/".$file_name; 	  	//移动文件 
			$headimg = "/uploads/image/avatar/".$file_name;  //文件保存路径
			
			$create_time = time();
			if(move_uploaded_file($uploaded_file,$move_to_file)) {  
				$sql = "INSERT INTO `#@__images` (  picurl, create_time ) VALUES( '$headimg', '$create_time')";
				if($dosql->ExecNoneQuery($sql))
				{
					ShowMsg("上传成功","-1");
					exit(); 
				}				
			} else {  
				ShowMsg("上传失败","-1");
				exit(); 
			}  
		} else {  
			ShowMsg("上传失败","-1");
			exit(); 
		}  
	} else{
		ShowMsg("你没有选择文件","-1");
		exit(); 
	}
}else if($action == 'insertData'){	//向数据库中插入数据
	$username = htmlspecialchars($username);
	$password = htmlspecialchars(md5(md5($password)));
	$mobile = htmlspecialchars($mobile);
	$create_time = time();
	
	//一个用户名只能提交一次(24小时内)
	$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
	$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
	
	$Info = $dosql->GetOne("select * from `#@__user` where mobile = '".$mobile."' or username='".$username."'");
	$msg = array();
	if($Info){
		$msg['status'] = 1;
		$msg['info'] = "用户名或手机号已存在！";
		echo json_encode($msg);
		exit(); 
	}
	//入库
	$sql = "INSERT INTO `#@__user` ( username, password, mobile, create_time) VALUES (
									  '$username', '$password', '$mobile', '$create_time')";
	if($dosql->ExecNoneQuery($sql))
	{	
		$msg['status'] = 1;
		$msg['info'] = "提交成功！";
		echo json_encode($msg);
		exit(); 
	}else{
		$msg['status'] = 0;
		$msg['info'] = "提交失败，请稍后再试！";;
		echo json_encode($msg);
		exit(); 	
	}
}else{//无条件返回
	exit('请求出错!');	
}
?>